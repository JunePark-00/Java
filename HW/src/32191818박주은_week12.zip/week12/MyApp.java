package week12;

public class MyApp {

	public static void main(String[] args) {
		@SuppressWarnings("unused")
		MyFrame frame = new MyFrame();
	}

}
